SESCO Cement Corp - Florida Market Intelligence Package
========================================================

This package contains interactive HTML reports for the Florida cement market analysis.

HOW TO USE:
-----------
1. Extract all files to the SAME folder
2. Open INDEX.html in your web browser (Chrome, Edge, Firefox recommended)
3. Click any report link to view that document
4. All reports will open in your browser - no special software needed

REPORTS INCLUDED:
-----------------
- INDEX.html                              - Main navigation page (START HERE)
- FLORIDA_CEMENT_EXECUTIVE_SUMMARY.html   - 2-page executive summary
- FLORIDA_CEMENT_MARKET_REPORT.html       - Full market analysis report
- PORT_REDWING_TRUCKING_MAP.html          - Interactive trucking radius map
- READYMIX_CUSTOMER_MAP.html              - Customer map (894 FL + 800 Gulf Coast plants)
- CEMENT_INFRASTRUCTURE_MAP.html          - US infrastructure map (requires internet)
- GLOBAL_TRADE_FLOW_MAP.html              - Import/export flow visualization
- CEMENT_MARKET_NATIONAL_DASHBOARD.html   - US market statistics
- CEMENT_MARKET_INTELLIGENCE_REPORT.html  - Competitive analysis
- CEMENT_MARKET_ARCGIS_EMBED.html         - ArcGIS Online map viewer (NEW: includes ready-mix layers)
- CEMENT_MARKET_PITCH_DECK.html           - Presentation slides

INTERNET REQUIREMENTS:
----------------------
- Most reports work offline after loading once
- CEMENT_INFRASTRUCTURE_MAP.html requires internet to load map layers
- CEMENT_MARKET_ARCGIS_EMBED.html requires internet for ArcGIS layers
- Maps use OpenStreetMap/CARTO tiles which require internet connection

NEW IN THIS VERSION:
--------------------
- Added 894 Florida ready-mix plants (EPA ECHO)
- Added 1,694 Gulf Coast ready-mix plants (FL, GA, AL, MS, LA, SC)
- Ready-mix layers visible in Florida, Tampa, and Trucking maps
- Updated stats and legends

DATA SOURCES:
-------------
- EPA ECHO (Ready-mix plant locations - NAICS 327320)
- Panjiva Trade Intelligence (Import/export data)
- Global Energy Monitor (Cement plant data)
- BTS NTAD (Transportation infrastructure)
- USGS (Market statistics)

Prepared for: SESCO Cement Corp
Date: December 2025
Contact: theshipsagent.com
